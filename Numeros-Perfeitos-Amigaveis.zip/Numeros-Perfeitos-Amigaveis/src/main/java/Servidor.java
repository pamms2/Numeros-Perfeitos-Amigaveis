import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Servidor {
    private static int porta = 20000; //porta de conexão
    private static BigInteger intervaloPerfeito = BigInteger.valueOf(10000); //intervalo total para verificar números perfeitos
    private static BigInteger intervaloAmigo = BigInteger.valueOf(10000);    //intervalo total para verificar pares amigáveis
    private static List<Socket> clientes = new ArrayList<>(); //lista de clientes conectados
    
    public static void main(String[] args) {
        try (ServerSocket servidor = new ServerSocket(porta)) {
            System.out.println("Servidor aguardando conexao...");

            // Aguarda o primeiro cliente indefinidamente
            Socket primeiraConexao = servidor.accept();
            synchronized (clientes) {
                clientes.add(primeiraConexao);
            }
            System.out.println("Primeiro cliente conectado: " + primeiraConexao.getInetAddress());

            //espera até 3 segundos para mais conexões
            long tempoLimite = System.currentTimeMillis() + 3000;

            while (System.currentTimeMillis() < tempoLimite) {
                servidor.setSoTimeout((int) (tempoLimite - System.currentTimeMillis()));
                try {
                    Socket conexaoAdicional = servidor.accept();
                    synchronized (clientes) {
                        clientes.add(conexaoAdicional);
                    }
                    System.out.println("Outro cliente conectado: " + conexaoAdicional.getInetAddress());
                } catch (IOException e) {
                    break; //se o timeout expirar, sai do loop
                }
            }

            //após o tempo limite ou máximo de conexões, distribui o intervalo
            distribuirIntervalos();

        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //método para dividir os intervalos de verificação entre os clientes conectados   
    private static void distribuirIntervalos() {
        int totalClientes = clientes.size();
        
        //divide os intervalos igualmente entre os clientes
        BigInteger tamanhoIntervaloPerfeito = intervaloPerfeito.divide(BigInteger.valueOf(totalClientes));
        BigInteger tamanhoIntervaloAmigo = intervaloAmigo.divide(BigInteger.valueOf(totalClientes));

        for(int i = 0; i < totalClientes; i++) {
            BigInteger inicioPerfeito = tamanhoIntervaloPerfeito.multiply(BigInteger.valueOf(i));
            BigInteger inicioAmigo = tamanhoIntervaloAmigo.multiply(BigInteger.valueOf(i));
            
            BigInteger fimPerfeito;
            BigInteger fimAmigo;

            //o último cliente recebe até o final do intervalo
            if(i == totalClientes - 1) {
                fimPerfeito = intervaloPerfeito.subtract(BigInteger.ONE);
                fimAmigo = intervaloAmigo.subtract(BigInteger.ONE);
            } else {
                fimPerfeito = inicioPerfeito.add(tamanhoIntervaloPerfeito).subtract(BigInteger.ONE);
                fimAmigo = inicioAmigo.add(tamanhoIntervaloAmigo).subtract(BigInteger.ONE);
            }

            Socket conexao = clientes.get(i);

            try {
                //envia os intervalos para o clientes via socket
                DataOutputStream saida = new DataOutputStream(conexao.getOutputStream());
                saida.writeUTF(inicioPerfeito.toString());
                saida.writeUTF(fimPerfeito.toString());
                saida.writeUTF(inicioAmigo.toString());
                saida.writeUTF(fimAmigo.toString());
                
                //encerra a conexão com o cliente após o envio de dados
                conexao.close();
            } catch(IOException ex) {
                Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //limpa a lista de clientes após a distribuição
        clientes.clear();
    }
}