
import java.math.BigInteger;

//Thread que percorre um subintervalo de p e verifica quais pares são amigáveis
public class ThreadParesAmigaveis implements Runnable{
    private BigInteger inicio;
    private BigInteger fim;
    
    //Início e fim do subintervalo p a ser verificado por esta thread
    //que vai ser definidio no cliente com base no intervalo completo
    public ThreadParesAmigaveis(BigInteger inicio, BigInteger fim) {
        this.inicio = inicio;
        this.fim = fim;
    }
    
    public void run() {
        BigInteger soma = BigInteger.ZERO;
        BigInteger somaPar = BigInteger.ZERO;
        
        for(BigInteger i = inicio; i.compareTo(fim) <= 0; i = i.add(BigInteger.ONE)) {
            
            for(BigInteger j = BigInteger.ONE; j.compareTo(i.divide(BigInteger.TWO)) <= 0 ; j = j.add(BigInteger.ONE)) {
                if (i.mod(j).equals(BigInteger.ZERO)) {
                    if(!j.equals(i)) {
                        soma = soma.add(j);
                    }
                }
            }
            
            if(soma.equals(i)) {
                soma = BigInteger.valueOf(0);
            } else {
                for(BigInteger k = BigInteger.ONE; k.compareTo(soma.divide(BigInteger.TWO)) <= 0; k = k.add(BigInteger.ONE)) {
                    if(soma.mod(k).equals(BigInteger.ZERO)) {
                        somaPar = somaPar.add(k);
                    }
                }

                
                if (somaPar.equals(i)) {
                    System.out.println("(" + i + "," + soma + ")");
                }

                soma = BigInteger.valueOf(0);
                somaPar = BigInteger.valueOf(0);
            }
        }
        
    }
}
