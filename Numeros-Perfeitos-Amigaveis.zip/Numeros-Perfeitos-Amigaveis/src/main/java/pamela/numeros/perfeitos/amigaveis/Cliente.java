package pamela.numeros.perfeitos.amigaveis;

import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {
    public static void main(String[] args) {
        String servidor = "localhost";
        int porta = 20000;
        
        try(Socket socket = new(servidor, porta)) {
            System.out.println("Conectado ao servidor.");
            
            
        } catch(IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
