
package pamela.numeros.perfeitos.amigaveis;

import java.math.BigInteger;

//Thread utilizada para paralelizar a verificação de números perfeitos
public class ThreadNumerosPerfeitos implements Runnable{
    BigInteger numero;
    
    public ThreadNumerosPerfeitos(BigInteger numero) {
        this.numero = numero;
    }
    
    public static boolean primo(BigInteger numero) {
        if (numero.compareTo(BigInteger.TWO) < 0) {
            return false;
        }
        if (numero.equals(BigInteger.TWO)) {
            return true;
        }
        if (numero.mod(BigInteger.TWO).equals(BigInteger.ZERO)) {
            return false;
        }

        BigInteger i = BigInteger.valueOf(3);
        BigInteger limite = sqrt(numero).add(BigInteger.ONE);
        while (i.compareTo(limite) <= 0) {
            if (numero.mod(i).equals(BigInteger.ZERO)) {
                return false;
            }
            i = i.add(BigInteger.TWO);
        }
        return true;
    }
    
    private static BigInteger sqrt(BigInteger n) {
        BigInteger a = BigInteger.ONE;
        BigInteger b = n.shiftRight(1).add(BigInteger.ONE);
        while (b.compareTo(a) >= 0) {
            BigInteger mid = a.add(b).shiftRight(1);
            if (mid.multiply(mid).compareTo(n) > 0) {
                b = mid.subtract(BigInteger.ONE);
            } else {
                a = mid.add(BigInteger.ONE);
            }
        }
        return a.subtract(BigInteger.ONE);
    }
    
    public void run() {
        if (primo(numero)) {
            BigInteger dois = BigInteger.valueOf(2);
            BigInteger mersenne = dois.pow(numero.intValue()).subtract(BigInteger.ONE);

            if (mersenne.isProbablePrime(10)) {
                BigInteger perfeito = dois.pow(numero.intValue() - 1).multiply(mersenne);
                System.out.println("Número perfeito gerado: " + perfeito);
            }
        }
    }
}
