import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {
    public static void main(String[] args) throws InterruptedException {
        String servidor = "localhost";
        int porta = 20000;
        
        try(Socket socket = new Socket(servidor, porta)) {
            System.out.println("Conectado ao servidor.");
            DataInputStream entrada = new DataInputStream(socket.getInputStream());
            BigInteger inicioPerfeito = new BigInteger(entrada.readUTF());
            BigInteger fimPerfeito = new BigInteger(entrada.readUTF());
            BigInteger inicioAmigo = new BigInteger(entrada.readUTF());
            BigInteger fimAmigo = new BigInteger(entrada.readUTF());
            
            
            System.out.println("Intervalo recebido para numeros perfeitos: "+inicioPerfeito+" ate "+fimPerfeito);
        
            Thread threadPerfeito = new Thread(new ThreadNumerosPerfeitos(inicioPerfeito, fimPerfeito));
            threadPerfeito.start();
            threadPerfeito.join();
            
            System.out.println("Cliente finalizou o processamento."); 
            DataOutputStream saida = new DataOutputStream(socket.getOutputStream());
        } catch(IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
